package com.nordan.sampleapp;

import androidx.appcompat.app.AppCompatActivity;

public class DefaultDialog extends AppCompatActivity {
}
