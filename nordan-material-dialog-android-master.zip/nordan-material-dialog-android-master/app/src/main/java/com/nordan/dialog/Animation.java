package com.nordan.dialog;

public enum Animation {
    POP, SIDE, SLIDE
}
