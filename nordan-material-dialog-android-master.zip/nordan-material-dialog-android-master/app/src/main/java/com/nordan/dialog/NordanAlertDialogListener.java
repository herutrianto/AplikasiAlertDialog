package com.nordan.dialog;

public interface NordanAlertDialogListener {

    void onClick();
}
