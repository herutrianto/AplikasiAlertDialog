package com.nordan.dialog;

public enum DialogType {
    WARNING,
    ERROR,
    INFORMATION,
    QUESTION,
    SUCCESS
}
